export declare class ShopOwnerModule {
}
