export declare class EventsModule {
}
