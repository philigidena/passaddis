export declare class OrganizerModule {
}
