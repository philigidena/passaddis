export declare class ShopModule {
}
