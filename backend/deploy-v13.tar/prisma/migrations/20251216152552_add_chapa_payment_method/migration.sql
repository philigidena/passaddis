-- AlterEnum
ALTER TYPE "PaymentMethod" ADD VALUE 'CHAPA';
